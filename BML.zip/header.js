function myfunction() {
    let sub = document.getElementById('sub');
    if (sub.style.display=="grid"){
        sub.style.display="None";
    }else{
        sub.style.display= "grid";
    }  
}
function myfunctions() {
    let sub = document.getElementById('down');
    if (sub.style.display=="block"){
        sub.style.display="None";
    }else{
        sub.style.display= "block";
    }  
}